#!/bin/bash

lines() { 
    echo "*************************"
    echo "$1"
    echo "-------------------------"
    echo ""
}

lines "checking packages (curl, unzip, sqlite3, libsqlite3-dev)"

check_command() {
    if ! [ -x "$(command -v $1)" ]; then
        lines "$1 isn't installed, installing $1"
		sudo apt install -y $1
    fi
}

check_package() {
    dpkg -s $1 &> /dev/null
    if [ $? -gt 0 ]; then
        lines "$1 isn't installed, installing $1"
		sudo apt install -y $1
    fi
}

check_command curl
check_command unzip
check_package sqlite3
check_package libsqlite3-dev

if [ -d "$HOME/.apps/bibijaan" ]; then rm -rf $HOME/.apps/bibijaan; fi
if [ -f "$HOME/.local/share/applications/bibijaan.desktop" ]; then rm $HOME/.local/share/applications/bibijaan.desktop; fi

mkdir -p $HOME/.apps

dirsh=$(dirname "$0")

unzip "$dirsh/bundle.zip" -d $HOME/.apps/bibijaan

cp "$dirsh/bibijaan.desktop" $HOME/.local/share/applications/bibijaan.desktop

sed -i 's,'~','"$HOME"',g' $HOME/.local/share/applications/bibijaan.desktop

lines "BiBiJAAN Desktop app should be installed!"
lines "Version: $(cat $HOME/.local/share/applications/bibijaan.desktop | grep 'Version' | cut -d '=' -f 2)"
lines "Installed path: $HOME/.apps/bibijaan"
lines "Desktop file: $HOME/.local/share/applications/bibijaan.desktop"
lines "Now open your application Launcher and search bibijaan"
lines "Or you can also run from terminal by typing: $HOME/.apps/bibijaan/bibijaan"

lines "Report any issue to: shout@bibijaan.com"
