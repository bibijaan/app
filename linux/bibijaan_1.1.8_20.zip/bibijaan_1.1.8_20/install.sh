#!/bin/bash

if [ -d $HOME/.apps/bibijaan ]; then rm -rf $HOME/.apps/bibijaan; fi
if [ -f $HOME/.local/share/applications/bibijaan.desktop ]; then rm $HOME/.local/share/applications/bibijaan.desktop; fi

mkdir -p $HOME/.apps

unzip $(dirname $0)/bundle.zip -d $HOME/.apps/bibijaan

cp $(dirname $0)/bibijaan.desktop $HOME/.local/share/applications/bibijaan.desktop

sed -i 's,'~','$HOME',g' $HOME/.local/share/applications/bibijaan.desktop
