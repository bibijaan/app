1. Extract full zip
2. Open Terminal
3. Run install.sh
   - Drag install.sh into Terminal app, then press enter
   - Or 'cd' into extracted directory, then type: ./install.sh and then press enter

Required packages: sudo apt install -y unzip sqlite3 libsqlite3-dev
